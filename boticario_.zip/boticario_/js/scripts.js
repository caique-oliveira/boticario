var boticario = {
    products: [],
    plugins: {},
    settings: {
        numColumns: 3,
        brand: "boticario",
        mode: "JSON",
        JSONFile: "products.json",
        fadeSpeed: 200,
        buttonColor: null,
        backgroundColor: null,
        textColor: null,
        container: $(".boticario_container"),
        cartContainer: $(".boticario_cart_container"),
        rowClass: "boticario_row_",
        columnWidthClasses: {
            1: "",
            2: "one-half",
            3: "one-third"
        }
    },
    productPageOptions: ["OneOfAKind"],
    extend: function(a, b, c) {
        var d;
        "undefined" == typeof b && (b = a, a = boticario);
        for (d in b) Object.prototype.hasOwnProperty.call(b, d) && (a[d] = b[d]);
        return c(), a
    },
    render: function(a, b) {
        var c = a.split("/")[0],
            d = {
                "": function() {
                    boticario.renderProducts(boticario.products, b)
                },
                "#product": function() {
                    var c = a.split("#product/")[1].trim();
                    boticario.renderSingleProduct(c, b)
                },
                "#cart": function() {
                    boticario.renderCart(b)
                }
            };
        d[c] ? d[c]() : boticario.renderError(b)
    },
    insertData: function(a, b) {
        a.find(".item_thumb").attr("src", b.image), a.find(".item_name").text(b.name), a.find(".item_price").text(b.price), a.find(".item_description").text(b.description)
    },
    renderProducts: function(a, b) {
        var c, d = 1,
            e = (a.length, Math.ceil(a.length / b.numColumns));
        b.cartContainer.hide(), b.container.fadeOut(b.fadeSpeed, function() {
            b.container.html("").fadeIn(b.fadeSpeed);
            for (var f = 0; e > f; f++) b.container.append('<div class="row ' + b.rowClass + (f + 1) + '"></div>');
            var g = b.columnWidthClasses;
            for (var h in g) h == b.numColumns && (c = g[h]);
            a.forEach(function(a, e) {
                var f = $("#products-template").html(),
                    g = $(f);
                g.first().addClass(c), boticario.insertData(g, a);
                var h = g.find(".boticario_getDetail");
                h.on("click", function(b) {
                    b.preventDefault(), window.location.hash = "product/" + a.id
                }), 0 === e && (e = 1), e % b.numColumns === 0 && d++, $("." + b.rowClass + d).append(g)
            })
        })
    },
    renderProductOptions: function(a, b) {
        var c = "";
        return a.forEach(function(b) {
            if (boticario.productPageOptions in b) boticario.renderProductPageOptions(b);
            else {
                var d = "",
                    e = Object.keys(b)[0].trim(),
                    f = b[e].trim().split(",");
                $(f).each(function(a, b) {
                    d += '<option value="' + b.replace(/ /g, "_").toLowerCase() + '"> ' + b + " </option>"
                }), a.length && (c += "<label>" + e + '</label><select class="item_' + e.replace(/ /g, "_").toLowerCase() + '">' + d + "</select>")
            }
        }), c
    },
    renderProductPageOptions: function(a) {
        a.OneOfAKind && $(".item_qty").hide()
    },
    renderSingleProduct: function(a, b) {
        b.container.fadeOut(b.fadeSpeed, function() {
            var c = $("#product-detail-template").html(),
                d = $(c);
            boticario.products.forEach(function(c) {
                if (c.id == a) {
                    if (boticario.insertData(d, c), b.container.html(d), c.options.length) {
                        var e = boticario.renderProductOptions(c.options, b);
                        $(".boticario_options").append(e)
                    }
                    b.container.fadeIn(b.fadeSpeed)
                }
            })
        })
    },
    renderCart: function(a) {
        a.container.fadeOut(a.fadeSpeed, function() {
            a.cartContainer.fadeIn(a.fadeSpeed)
        })
    },
    renderError: function(a, b) {
        var c = $("#error-template").html(),
            d = $(c);
        a.container.html("").fadeIn(a.fadeSpeed), b.length && d.find(".error_text").text(b), a.container.append(d), a.container.fadeIn(a.fadeSpeed), d.find(".alert_close").on("click", function(b) {
            b.preventDefault(), d.fadeOut(a.fadeSpeed, function() {
                d.remove()
            })
        })
    },
    handleFailure: function(a, b) {
        setTimeout(function() {
            boticario.renderError(a, b)
        }, 1e3)
    },
    initJSON: function(a) {
        var b = 'There was an error loading the JSON file. Please make sure you have "' + a.JSONFile + '" file in your main directory.';
        $.get(a.JSONFile).success(function() {
            $.getJSON(a.JSONFile, function(a) {
                boticario.setProducts(a.products)
            }).fail(function() {
                boticario.handleFailure(a, b)
            })
        }).fail(function() {
            boticario.handleFailure(a, b)
        })
    },
    checkMode: function(a) {
        (a.hasOwnProperty("spreadsheetID") || a.hasOwnProperty("spreadsheetId")) && (a.mode = "Google")
    },
    checkout: function(a, b) {
        $.isEmptyObject(b) || (simpleCart.checkout(), a.cartContainer.fadeOut(a.fadeSpeed, function() {
            a.container.html('<i class="fa fa-spin fa-circle-o-notch loader"></i>'), a.container.fadeIn(a.fadeSpeed)
        }))
    },
    verifyCheckoutData: function(a, b, c) {
        for (var d in a)
            if (a.hasOwnProperty(d))
                for (var e = a[d], f = e.name, g = e.price, h = 0; h < b.length; h++) {
                    var i = b[h],
                        j = i.name,
                        k = i.price;
                    f === j && g != k && (c = !1)
                }
            return c
    },
    validatePrices: function(a) {
        var b = JSON.parse(localStorage.simpleCart_items),
            c = "There was an error validating your cart.";
        if ("JSON" === a.mode) $.get(a.JSONFile).success(function() {
            $.getJSON(a.JSONFile, function(d) {
                var e = d.products;
                boticario.verifyCheckoutData(b, e, !0) ? boticario.checkout(a, b) : boticario.renderError(a, c)
            }).fail(function() {
                boticario.handleFailure(a, c)
            })
        }).fail(function() {
            boticario.handleFailure(a, c)
        });
        else {
            var d = a.mode.toLowerCase();
            boticario.plugins[d] && boticario.plugins[d].validate(b)
        }
    },
    setProducts: function(a, b) {
        a.length > 0 && a.forEach(function(a, b) {
            a.id = b + 1, boticario.products.push(a)
        }), $(window).trigger("hashchange")
    },
    setLayout: function(a) {
        a.brand.match("^http://") || a.brand.match("^https://") || a.brand.match("^www.") ? $(".brand").html('<img src="' + a.brand + '" />') : $(".brand").html("<h5>" + a.brand + "</h5>"), $("title").html(a.brand)
    },
    generateCart: function(a) {
        var b = $("#cart-template").html(),
            c = $(b);
        a.cartContainer.html(c)
    },
    generateStore: function() {
        var a = this.settings;
        switch (this.checkMode(a), $(window).on("hashchange", function() {
            boticario.render(window.location.hash, a)
        }), a.mode) {
            case "JSON":
                this.initJSON(a);
                break;
            case "Google":
                if (boticario.plugins.google) boticario.plugins.google.init(function(b) {
                    boticario.setProducts(b, a)
                });
                else {
                    var b = "There was an error loading the Google plugin. Make sure it is installed properly.";
                    boticario.renderError(a, b)
                }
                break;
            default:
                this.initJSON(a)
        }
        this.generateCart(a), this.setLayout(a), $(".boticario_checkout").on("click", function(b) {
            b.preventDefault(), boticario.validatePrices(a)
        }), $(".boticario_viewCart").on("click", function(a) {
            a.preventDefault(), window.location = "#cart"
        }), $(".view_close").on("click", function(a) {
            a.preventDefault(), window.location.hash = ""
        })
    },
    init: function(a) {
        return $.isPlainObject(a) ? this.extend(this.settings, a, function() {
            boticario.generateStore()
        }) : void 0
    }
};
$(document).ready(function (){
        $(".simpleCart_total").hide();

        $(".fa-shopping-cart").mouseover(function() {
            $(".simpleCart_total").show();
        });

        $(".fa-shopping-cart").mouseleave(function() {
            $(".simpleCart_total").hide();
        });
        $(".fa-shopping-cart").mouseover(function(){
            $(".fa-shopping-cart").css("width","130px")
        });
        $(".fa-shopping-cart").mouseleave(function() {
            $(".fa-shopping-cart").css("width","70px")
        });
}); 